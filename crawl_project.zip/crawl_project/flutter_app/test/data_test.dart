import 'package:crawl_app/data/api_client.dart';
import 'package:crawl_app/data/models.dart';
import 'package:crawl_app/data/settings_store.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parseSse tách sự kiện, bỏ ping, nối nhiều dòng data, bỏ sự kiện hỏng', () async {
    final lines = Stream<String>.fromIterable(<String>[
      'id: 0',
      'event: status',
      'data: {"seq":0,"type":"status","status":"running"}',
      '',
      ': ping',
      '',
      'id: 1',
      'data: {"seq":1,',
      'data: "type":"start","total":6}',
      '',
      'data: {khong phai json',
      '',
      'data: {"seq":2,"type":"end","status":"done"}',
      '',
    ]);
    final events = await parseSse(lines).toList();
    expect(events.map((e) => e['seq']).toList(), <Object?>[0, 1, 2]);
    expect(events[1]['total'], 6);
  });

  test('parseSse: sự kiện cuối không có dòng trống kết thúc thì bị bỏ (server luôn gửi dòng trống)', () async {
    final events = await parseSse(Stream<String>.fromIterable(<String>['data: {"seq":0,"type":"x"}'])).toList();
    expect(events, isEmpty);
  });

  test('Job.fromJson khớp docs/API.md', () {
    final job = Job.fromJson(<String, dynamic>{
      'id': 'a1b2c3d4e5f6',
      'url': 'https://toctruyen.net/truyen/abc/ban-trai',
      'site': 'toctruyen',
      'title': '',
      'start': 1,
      'end': 50,
      'workers': 4,
      'delay': 0.15,
      'out_dir': 'C:\\Truyen',
      'output_file': 'C:\\Truyen\\ban-trai.txt',
      'status': 'running',
      'done': 12,
      'total': 50,
      'result': null,
      'error': null,
      'created_at': '2026-10-11T09:00:00+00:00',
      'started_at': null,
      'finished_at': null,
    });
    expect(job.isActive, isTrue);
    expect(job.progress, closeTo(0.24, 1e-9));
    expect(job.displayName, 'ban-trai');
    expect(job.createdAt, isNotNull);
    expect(job.startedAt, isNull);
  });

  test('Job.progress là null khi chưa biết tổng số chương', () {
    final job = Job.fromJson(<String, dynamic>{'id': 'x', 'status': 'queued'});
    expect(job.progress, isNull);
    expect(job.isActive, isTrue);
  });

  test('Job.copyWith giữ nguyên các trường còn lại', () {
    final job = Job.fromJson(<String, dynamic>{'id': 'x', 'title': 'T', 'status': 'running', 'done': 1, 'total': 5});
    final next = job.copyWith(done: 2, status: 'done');
    expect(next.done, 2);
    expect(next.total, 5);
    expect(next.title, 'T');
    expect(next.isFinished, isTrue);
  });

  test('JobEvent đọc result của sự kiện end', () {
    final ev = JobEvent.fromJson(<String, dynamic>{
      'seq': 52,
      'type': 'end',
      'status': 'done',
      'result': <String, dynamic>{
        'output_file': 'x.txt',
        'requested': 6,
        'saved': 4,
        'failed_numbers': <int>[2, 5],
        'chars': 1000,
        'seconds': 1.5,
        'cancelled': false,
      },
      'error': null,
    });
    expect(ev.result!.failedNumbers, <int>[2, 5]);
    expect(ev.result!.saved, 4);
    expect(ev.error, isNull);
  });

  test('StoryInfo.fromJson', () {
    final info = StoryInfo.fromJson(<String, dynamic>{
      'site': 'toctruyen',
      'url': 'u',
      'title': 'Tên Truyện',
      'chapters_found': 10,
      'max_chapter_number': 10,
      'announced_total': 120,
      'warnings': <String>['Lấy được 10 chương nhưng site công bố 120'],
    });
    expect(info.announcedTotal, 120);
    expect(info.warnings, hasLength(1));
  });

  test('AppSettings.fromJson kẹp workers/delay vào khoảng cho phép', () {
    final s = AppSettings.fromJson(<String, dynamic>{'workers': 99, 'delay': -3, 'outDir': 'C:\\X'});
    expect(s.workers, 8);
    expect(s.delay, 0.0);
    expect(s.outDir, 'C:\\X');
  });
}
